//
//  DataManager.swift
//  discussion
//
//  Created by 호빈 on 2021/02/21.
//

import Foundation
import CoreData

class DataManager {
    //공유 인스턴스를 저장할 타입 프로퍼티
    static let shared = DataManager()
    
    //기본 생성자를 추가하고 프라비잇으로 생성하면 앱전체에서 하나의 인스턴스로 공유가능(싱글톤)
    private init() {
        
    }
    
    var mainContenxt: NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    //메모를 데이터베이스에서 읽어오기
    
    var DiscussionList = [Discussion]()
    
    func fetchDiscussion() {
        let request: NSFetchRequest<Discussion> = Discussion.fetchRequest()
        
        let sortByDateDesc = NSSortDescriptor(key: "insertDate",
            ascending: false) //날짜 내림차순 정렬
        request.sortDescriptors = [sortByDateDesc]
        
        
        do {
            DiscussionList = try mainContenxt.fetch(request)
        } catch {
            print(error)
        }
    }
    
    func addNewDiscussion(_ title: String?, _ content: String?) {
        let newDiscussion = Discussion(context: mainContenxt)
        newDiscussion.title = title
        newDiscussion.content = content
        newDiscussion.insertDate = Date()
        
        DiscussionList.insert(newDiscussion, at: 0)
        
        saveContext()
    }
    
    //2. 삭제: 메소드 구현
    
    func deleteDiscussion(_ discussion: Discussion?) {
        if let discussion = discussion {
            mainContenxt.delete(discussion)
            saveContext()
        }
    }
    
    
    // MARK: - Core Data stack

    lazy var persistentContainer: NSPersistentContainer = {
        
        let container = NSPersistentContainer(name: "discussion")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
              
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()

    // MARK: - Core Data Saving support

    func saveContext () {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
}
