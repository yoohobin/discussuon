//
//  Model.swift
//  discussion
//
//  Created by 호빈 on 2021/02/17.
//

import Foundation

//class Discussion {
//    var title: String
//    var insertDate: Date
//    var content: String
//    
//    init(title: String, content: String) {
//        self.title = title
//        self.content = content
//        insertDate = Date()
//    }
//    
//    static var dummyDiscussionList = [
//        Discussion(title: "제목", content: "내용"),
//        Discussion(title: "에휴", content: "언제다해")
//    ]
//        
//}
