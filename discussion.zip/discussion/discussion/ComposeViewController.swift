//
//  ComposeViewController.swift
//  discussion
//
//  Created by 호빈 on 2021/02/20.
//

import UIKit

class ComposeViewController: UIViewController {
    
    
    @IBAction func close(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    

    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var contentTextView: UITextView!
    
    @IBAction func save(_ sender: Any) {
        
        guard let title = titleTextField.text,
            title.count > 0 else {
            alert(message: "제목을 입력하세요")
            return
        }
        
        guard let content = contentTextView.text,
            content.count > 0 else {
            alert(message: "내용을 입력하세요")
            return
        }
        
        let newDiscussion = Discussion(title: title, content: content)
        Discussion.dummyDiscussionList.append(newDiscussion)
        
        //2. Notification: 화면을 닫기 전 Notification을 전달
        NotificationCenter.default.post(name: ComposeViewController.newdiscussionDidInsert, object: nil)
        
        dismiss(animated: true, completion: nil)
        

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

      
    }
    
}

/*1. Notification: 라디오 방송이라 생각하면 된다. 그리고 라이오 방송국에 해당하는 NotificationCenter가 있음.
 라디오는 우리가 주파수를 통해서 구분할 수 있음 Notification은 이름으로 구분*/
extension ComposeViewController {
    static let newdiscussionDidInsert = Notification.Name(rawValue: "newdiscussionDidInsert")
}

