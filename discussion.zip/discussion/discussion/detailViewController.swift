//
//  detailViewController.swift
//  discussion
//
//  Created by 호빈 on 2021/02/20.
//

import UIKit

class detailViewController: UIViewController {
    
    let formatter: DateFormatter = {
        let f = DateFormatter()
        f.dateStyle = .long
        f.timeStyle = .short
        f.locale = Locale(identifier: "Ko_kr")
        return f
    }()
    
    var discussion: Discussion?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}

extension detailViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.row {
        case 0:
            let cell = tableView.dequeueReusableCell(withIdentifier: "titleCell", for: indexPath)
            
            cell.textLabel?.text = discussion?.title
            
            return cell
        case 1:
            let cell = tableView.dequeueReusableCell(withIdentifier: "contentCell", for: indexPath)
            
            cell.textLabel?.text = discussion?.content
            
            return cell
        case 2:
            let cell = tableView.dequeueReusableCell(withIdentifier: "dateCell", for: indexPath)
            
            cell.textLabel?.text = formatter.string(for: discussion?.insertDate)
            
            return cell
        default:
            fatalError()
        }
    }
}
