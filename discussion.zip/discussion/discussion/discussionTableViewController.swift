//
//  discussionTableViewController.swift
//  discussion
//
//  Created by 호빈 on 2021/02/17.
//

import UIKit

class discussionTableViewController: UITableViewController {
    
    let formatter: DateFormatter = {
        let f = DateFormatter()
        f.dateStyle = .long
        f.timeStyle = .short
        f.locale = Locale(identifier: "Ko_kr")
        return f
    }()
    
    
    //viewcontroller가 관리하는 view가 화면에 표시되기 직전에 자동으로 호출됨
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
//
//        tableView.reloadData()
//        print(#function)
    }
    
    
    //token은 addObserver로 데이터를 찾고나면 불필요한 데이터가 축적되기 때문에 삭제?
    var token: NSObjectProtocol?
    
    deinit {
        if let token = token {
            NotificationCenter.default.removeObserver(token)
        }
    }
    
  
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let cell = sender as? UITableViewCell, let indexPath = tableView.indexPath(for: cell) {
            if let vc = segue.destination as? detailViewController {
            vc.discussion = Discussion.dummyDiscussionList[indexPath.row]
            }
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //3. Notification
        token = NotificationCenter.default.addObserver(forName: ComposeViewController.newdiscussionDidInsert, object: nil, queue: OperationQueue.main) { [weak self] (noti) in
            self?.tableView.reloadData()
        }
    }
    

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        return Discussion.dummyDiscussionList.count
    }

   
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? ListCell else {
            return UITableViewCell()
        }
        
        let target = Discussion.dummyDiscussionList[indexPath.row]
        cell.titleLabel?.text = target.title
        cell.timeLabel?.text = formatter.string(from: target.insertDate)
        cell.contentLabel?.text = target.content
        return cell
    }
}

class ListCell: UITableViewCell {
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var contentLabel: UILabel!
}
